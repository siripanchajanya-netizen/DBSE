const express = require("express");
const Student = require("../models/Student");

const router = express.Router();

// CREATE
router.post("/", async (req, res) => {
    const student = await Student.create(req.body);
    res.json(student);
});

// READ
router.get("/", async (req, res) => {
    const students = await Student.find();
    res.json(students);
});

// UPDATE
router.put("/:id", async (req, res) => {
    const student = await Student.findByIdAndUpdate(
        req.params.id,
        req.body,
        { new: true }
    );
    res.json(student);
});

// DELETE
router.delete("/:id", async (req, res) => {
    await Student.findByIdAndDelete(req.params.id);
    res.json({ message: "Student deleted" });
});

module.exports = router;