const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const path = require("path");

const studentRoutes = require("./routes/studentRoutes");

const app = express();

app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://127.0.0.1:27017/studentdb")
    .then(() => console.log("MongoDB connected"))
    .catch(err => console.log(err));

app.use(express.static(path.join(__dirname, "public")));

app.use("/students", studentRoutes);

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});
